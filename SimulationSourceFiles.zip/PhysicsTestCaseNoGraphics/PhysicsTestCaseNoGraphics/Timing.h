#pragma once


class timer
{


};